import time
import random
from typing import Dict, List, Any
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service

def jitter_sleep(base: float = 1.2, jitter: float = 0.8) -> None:
    time.sleep(base + random.random() * jitter)

def parse_citation_table(driver) -> Dict[str, Dict[str, int]]:
    table = driver.find_element(By.ID, "gsc_rsb_st")
    rows = table.find_elements(By.CSS_SELECTOR, "tr")
    # Header has something like: All | Since 2019 (varies)
    header_cells = rows[0].find_elements(By.CSS_SELECTOR, "th")
    col_names = [c.text.strip() for c in header_cells][1:]  # skip the first empty header
    metrics: Dict[str, Dict[str, int]] = {}
    for r in rows[1:]:
        cells = r.find_elements(By.CSS_SELECTOR, "td")
        if len(cells) < 3:
            continue
        metric_name = cells[0].text.strip()
        values = [cells[1].text.strip(), cells[2].text.strip()]
        # Convert to int safely
        def to_int(x: str) -> int:
            try:
                return int(x.replace(",", ""))
            except ValueError:
                return -1
        metrics[metric_name] = {col_names[i]: to_int(values[i]) for i in range(min(2, len(col_names)))}
    return metrics


def get_publications(driver, limit: int = 5) -> List[Dict[str, Any]]:
    pubs = []
    rows = driver.find_elements(By.CSS_SELECTOR, "tr.gsc_a_tr")[:limit]
    for row in rows:
        title_el = row.find_element(By.CSS_SELECTOR, "a.gsc_a_at")
        title = title_el.text.strip()
        year_el = row.find_element(By.CSS_SELECTOR, "span.gsc_a_h.gsc_a_hc.gs_ibl")
        # sometimes year is in another span:
        if not year_el.text.strip():
            year_el = row.find_element(By.CSS_SELECTOR, "span.gsc_a_y span")
        year_text = year_el.text.strip()

        pubs.append({"title": title, "year": year_text})
    return pubs

def scrape_scholar_profile(profile_url: str, pub_limit: int = 5) -> Dict[str, Any]:
    chrome_options = Options()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--window-size=1400,900")
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_argument("--lang=en-US")
    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=chrome_options,
    )
    try:
        driver.get(profile_url)
        wait = WebDriverWait(driver, 15)
        wait.until(EC.presence_of_element_located((By.ID, "gsc_prf_in")))
        jitter_sleep()
        name = driver.find_element(By.ID, "gsc_prf_in").text.strip()
        # Affiliation is usually in #gsc_prf_i > div.gsc_prf_il
        # We’ll take the first "gsc_prf_il" as affiliation if present.
        affiliation = ""
        aff_elems = driver.find_elements(By.CSS_SELECTOR, "#gsc_prf_i .gsc_prf_il")
        if aff_elems:
            affiliation = aff_elems[0].text.strip()
        metrics = parse_citation_table(driver)
        publications = get_publications(driver, limit=pub_limit)
        return {
            "name": name,
            "affiliation": affiliation,
            "metrics": metrics,
            "publications": publications,
        }
    finally:
        driver.quit()
if __name__ == "__main__":
    michael_url = "https://scholar.google.com/citations?hl=en&user=RHcPtfkAAAAJ&view_op=list_works&sortby=pubdate"
    data = scrape_scholar_profile(michael_url, pub_limit=2)
    print(data)
